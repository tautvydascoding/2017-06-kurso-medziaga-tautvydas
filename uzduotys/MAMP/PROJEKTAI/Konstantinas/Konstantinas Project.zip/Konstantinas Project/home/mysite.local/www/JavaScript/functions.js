function checkForm(form) {
	var name = form.name.value;
	var phone = form.phone.value;
	var bad = "";
	if (name.length == 0) bad +="You did not enter a name" + "\n";
	if (phone.length == 0) bad  += "You did not enter a phone" + "\n";
	if (bad) {
		alert(bad);
		return false;
	}
    return true;
}
		