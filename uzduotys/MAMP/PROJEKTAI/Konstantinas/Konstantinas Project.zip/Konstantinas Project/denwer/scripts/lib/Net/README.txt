MySQL8.pm is for old-passwords MySQL directive (used in Denwer).
MySQL9.pm - for new MySQL 4.1 authentication method.

IO::Socket stub is used for this class.