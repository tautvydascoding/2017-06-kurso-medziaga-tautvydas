package strict;


return 1;
