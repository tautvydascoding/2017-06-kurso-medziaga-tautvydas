      <?if (!@$USE_HEAD) {?>
        <br/><br/>
        <HR noshade="noshade" />
        <?=$_SERVER["SERVER_SIGNATURE"]?>
      <?}?>
    </div>
  </td>
  <td bgcolor="#000000">&nbsp;</td>
</tr>
</table>
</body>
</html>
